import java.io.*;
import java.util.*;
public class StudentRecordSystem
{
    static final String FILE_NAME = "andrei_student.txt";
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(true){
            System.out.println("\nSTUDENT RECORD SYSTEM");
            System.out.println("1. Add Record");
            System.out.println("2. Edit Record");
            System.out.println("3. Delete Record");
            System.out.println("4. Search Record");
            System.out.println("5. View All Records");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1: addRecord(sc); break;
                case 2: editRecord(sc); break;
                case 3: deleteRecord(sc); break;
                case 4: searchRecord(sc); break;
                case 5: viewRecords(); break;
                case 6: System.exit(0);
                default:
                    System.out.println("Invalid option");

            }
        }
    }
    static void addRecord(Scanner sc){
        try{
            FileWriter fw = new FileWriter(FILE_NAME, true);
            System.out.print("Enter ID: ");
            String id = sc.nextLine();
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            
            fw.write(id + "," + name + "\n");
            fw.close();
            
            System.out.println("Record added.");
        }catch(IOException e){
            System.out.println("Error adding record");
        }
    }
    static void viewRecords(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;
            System.out.println("\nStudent Records");
            
            while((line = br.readLine()) != null){
                System.out.println(line);
            }
            
            br.close();
        }catch(IOException e){
            System.out.println("Error reading file");
        }
    }
    static void searchRecord(Scanner sc){
        System.out.print("Enter ID to search: ");
        String id = sc.nextLine();
        
        try{
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;
            boolean found = false;
            
            while((line = br.readLine()) != null){
                String[] data = line.split(",");
                if(data[0].equals(id)){
                    System.out.println("Record Found: " + line);
                    found = true;
                }
            }
            
            br.close();
            if(!found) System.out.println("Record not found");
        }catch(IOException e){
            System.out.println("Error searching file");
        }
    }
    static void editRecord(Scanner sc){
        System.out.print("Enter ID to edit: ");
        String id = sc.nextLine();
        
        File masterFile = new File(FILE_NAME);
        File tempFile = new File("temp.txt");
        
        try{
            BufferedReader br = new BufferedReader(new FileReader(masterFile));
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
            String line;
            
            while((line = br.readLine()) != null){
                String[] data = line.split(",");
                if(data[0].equals(id)){
                    System.out.print("Enter new name: ");
                    String newName = sc.nextLine();
                    bw.write(id + "," + newName);
                }else{
                    bw.write(line);
                }
                bw.newLine();
            }
            br.close();
            bw.close();
            
            masterFile.delete();
            tempFile.renameTo(masterFile);
            
            System.out.println("Record updated.");
        }catch(IOException e){
            System.out.println("Error editing record");
        }
    }
    static void deleteRecord(Scanner sc){
        System.out.print("Enter ID to delete: ");
        String id = sc.nextLine();
        
        File masterFile = new File(FILE_NAME);
        File tempFile = new File("temp.txt");
        
        try{
            BufferedReader br = new BufferedReader(new FileReader(masterFile));
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
            String line;
            
            while((line = br.readLine()) != null){
                String[] data = line.split(",");
                if(!data[0].equals(id)){
                    bw.write(line);
                    bw.newLine();
                }
            }
            br.close();
            bw.close();
            
            masterFile.delete();
            tempFile.renameTo(masterFile);
            
            System.out.println("Record deleted.");
        }catch(IOException e){
            System.out.println("Error deleting record");
        }
    }
}