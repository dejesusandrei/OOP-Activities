import java.io.FileWriter;
import java.io.IOException;
public class WriteExample {
    public static void main(String[] args) {
        try{
            FileWriter writer = new FileWriter("students.txt");
            writer.write("VEga Bayot\n");
            writer.write("Edison Bding\n");
            writer.write("Edishing\n");
            writer.close();
            System.out.println("Data written successfully.");
        }catch(IOException e){
            System.out.println("Error writing file");
        }
    }
}